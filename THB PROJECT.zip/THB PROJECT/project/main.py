# main.py
from flask import Flask, redirect, render_template, flash, request, session, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, LoginManager, login_required, logout_user, login_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import json
from flask_mail import Mail
from datetime import datetime
import requests
# -------------------- Initialize Flask --------------------
THB = Flask(__name__)
THB.secret_key = "sabrim"  # ⚠️ Move to environment variable in production

# -------------------- Load Config --------------------
with open('config.json', 'r') as c:
    params = json.load(c)["params"]

# -------------------- Database Setup --------------------
THB.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{params['db_user']}:{params['db_pass']}@localhost/{params['db_name']}"
THB.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(THB)

# -------------------- Mail Setup --------------------
THB.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=465,
    MAIL_USE_SSL=True,
    MAIL_USERNAME=params['gmail-user'],
    MAIL_PASSWORD=params['gmail-password']
)
mail = Mail(THB)

# -------------------- Login Manager --------------------
login_manager = LoginManager(THB)
login_manager.login_view = 'login'

# -------------------- Decorators --------------------
def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session or session.get('user') != params['user']:
            flash("Admin access required", "danger")
            return redirect(url_for('admin'))
        return f(*args, **kwargs)
    return decorated

def hospital_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not isinstance(current_user, HospitalUser):
            flash("Hospital login required", "danger")
            return redirect(url_for('hospitallogin'))
        return f(*args, **kwargs)
    return decorated

def patient_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not isinstance(current_user, User):
            flash("Patient login required", "danger")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# -------------------- Models --------------------
class Test(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    srfid = db.Column(db.String(20), unique=True)
    email = db.Column(db.String(50))
    dob = db.Column(db.String(100))
    password = db.Column(db.String(1000))

class HospitalUser(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hcode = db.Column(db.String(20), unique=True)
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(1000))

class HospitalData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hcode = db.Column(db.String(20), unique=True)
    hname = db.Column(db.String(100))
    normalbed = db.Column(db.Integer)
    hicubed = db.Column(db.Integer)
    icubed = db.Column(db.Integer)
    vbed = db.Column(db.Integer)

class BookingPatient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    srfid = db.Column(db.String(20))
    bedtype = db.Column(db.String(100))
    hcode = db.Column(db.String(20))
    spo2 = db.Column(db.Integer)
    pname = db.Column(db.String(100))
    pphone = db.Column(db.String(100))
    paddress = db.Column(db.String(100))
    payment_status = db.Column(db.String(20), default="Pending")
    payment_method = db.Column(db.String(50), default="Cash")

class Trigger(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    hcode = db.Column(db.String(20))
    normalbed = db.Column(db.Integer)
    hicubed = db.Column(db.Integer)
    icubed = db.Column(db.Integer)
    vbed = db.Column(db.Integer)
    querys = db.Column(db.String(50))
    date = db.Column(db.String(50))

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    srfid = db.Column(db.String(50), nullable=False)
    pname = db.Column(db.String(100), nullable=False)
    hcode = db.Column(db.String(20), nullable=False)
    bedtype = db.Column(db.String(20), nullable=False)
    payment_method = db.Column(db.String(20), nullable=False)
    spo2 = db.Column(db.Integer, nullable=True)
    pphone = db.Column(db.String(20), nullable=True)
    paddress = db.Column(db.String(200), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)



# -------------------- User Loader --------------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id)) or HospitalUser.query.get(int(user_id))

# -------------------- Utilities --------------------
def log_trigger(hospital, action):
    entry = Trigger(
        hcode=hospital.hcode,
        normalbed=hospital.normalbed,
        hicubed=hospital.hicubed,
        icubed=hospital.icubed,
        vbed=hospital.vbed,
        querys=action,
        date=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )
    db.session.add(entry)
    db.session.commit()

# -------------------- Routes --------------------
@THB.route('/')
def index():
    return render_template('index.html')

@THB.route('/home')
def home():
    return render_template('base.html')

# -------------------- Admin --------------------
@THB.route('/admin', methods=['POST', 'GET'])
def admin():
    if request.method == "POST":
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        if username == params['user'] and password == params['password']:
            session['user'] = username
            flash("Admin login successful!", "success")
            return redirect(url_for("add_hospital_user"))
        else:
            flash("Invalid Credentials", "danger")
    return render_template("admin.html")

@THB.route("/logoutadmin")
@admin_required
def logoutadmin():
    session.pop('user')
    flash("Admin logged out", "primary")
    return redirect(url_for('admin'))

@THB.route('/addhospitaluser', methods=['POST', 'GET'])
@admin_required
def add_hospital_user():
    if request.method == "POST":
        hcode = request.form.get('hcode', '').upper()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        encpassword = generate_password_hash(password)
        existing = HospitalUser.query.filter((HospitalUser.email == email) | (HospitalUser.hcode == hcode)).first()
        if existing:
            flash("Email or Hospital Code already exists", "warning")
        else:
            try:
                new_user = HospitalUser(hcode=hcode, email=email, password=encpassword)
                db.session.add(new_user)
                db.session.commit()
                flash("Hospital user added successfully", "success")
            except Exception as e:
                db.session.rollback()
                flash(f"Error: {str(e)}", "danger")
    return render_template("addhosuser.html")

# -------------------- Hospital --------------------
@THB.route('/hospitallogin', methods=['POST', 'GET'])
def hospitallogin():
    if request.method == "POST":
        email = request.form.get('email')
        password = request.form.get('password')
        user = HospitalUser.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            flash("Login Success", "info")
            return redirect(url_for("addhospitalinfo"))
        flash("Invalid Credentials", "danger")
    return render_template("hospitallogin.html")

@THB.route("/addhospitalinfo", methods=['POST', 'GET'])
@login_required
@hospital_required
def addhospitalinfo():
    data = HospitalData.query.filter_by(hcode=current_user.hcode).first()
    if request.method == "POST":
        hname = request.form.get('hname', '').strip()
        nbed = int(request.form.get('normalbed', 0))
        hbed = int(request.form.get('hicubeds', 0))
        ibed = int(request.form.get('icubeds', 0))
        vbed = int(request.form.get('ventbeds', 0))
        if data:
            flash("Data already exists. Update instead.", "warning")
        else:
            new_data = HospitalData(hcode=current_user.hcode, hname=hname, normalbed=nbed, hicubed=hbed, icubed=ibed, vbed=vbed)
            db.session.add(new_data)
            db.session.commit()
            log_trigger(new_data, "INSERT")
            flash("Hospital data added successfully", "success")
    return render_template("hospitaldata.html", postsdata=data)

@THB.route("/gethospitalinfo")
@login_required
@hospital_required
def gethospitalinfo():
    data = HospitalData.query.filter_by(hcode=current_user.hcode).first()
    return render_template("hospitaldata_partial.html", postsdata=data)




# Edit hospital info
@THB.route("/hedit/<int:id>", methods=['POST', 'GET'])
@login_required
@hospital_required
def hedit(id):
    post = HospitalData.query.filter_by(id=id, hcode=current_user.hcode).first()
    if not post:
        flash("Hospital record not found", "warning")
        return redirect(url_for("addhospitalinfo"))  # Back to main page
    if request.method == "POST":
        post.hname = request.form.get('hname', '').strip()
        post.normalbed = int(request.form.get('normalbed', 0))
        post.hicubed = int(request.form.get('hicubeds', 0))
        post.icubed = int(request.form.get('icubeds', 0))
        post.vbed = int(request.form.get('ventbeds', 0))
        db.session.commit()
        log_trigger(post, "UPDATE")
        flash("Hospital data updated successfully", "info")
        return redirect(url_for("addhospitalinfo"))  # Redirect after update
    return render_template("hedit.html", posts=post)


@THB.route("/hdelete/<int:id>")
@login_required
@hospital_required
def hdelete(id):
    post = HospitalData.query.filter_by(id=id, hcode=current_user.hcode).first()
    if post:
        db.session.delete(post)
        db.session.commit()
        log_trigger(post, "DELETE")
        flash("Hospital record deleted", "danger")
    else:
        flash("Hospital record not found", "warning")
    return redirect(url_for("addhospitalinfo"))

# -------------------- Patient --------------------
@THB.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == "POST":
        srfid = request.form.get('srf')
        email = request.form.get('email')
        dob = request.form.get('dob')
        password = request.form.get('password')
        if not all([srfid, email, dob, password]):
            flash("All fields required", "danger")
            return render_template("usersignup.html")
        if User.query.filter_by(srfid=srfid).first():
            flash("SRFID already exists", "warning")
            return redirect(url_for('login'))
        encpassword = generate_password_hash(password)
        new_user = User(srfid=srfid, email=email, dob=dob, password=encpassword)
        db.session.add(new_user)
        db.session.commit()
        flash("Signup success. Please login.", "success")
        return redirect(url_for('login'))
    return render_template("usersignup.html")

@THB.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated and isinstance(current_user, User):
        return redirect(url_for('slotbooking'))
    if request.method == "POST":
        srfid = request.form.get('srf', '').strip()
        password = request.form.get('password', '').strip()
        user_record = User.query.filter_by(srfid=srfid).first()
        if user_record and check_password_hash(user_record.password, password):
            login_user(user_record)
            flash("Login successful!", "success")
            return redirect(url_for('slotbooking'))
        flash("Invalid SRFID or Password.", "danger")
    return render_template("userlogin.html")

@THB.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logged out", "info")
    return redirect(url_for('login'))

# -------------------- Booking --------------------
@THB.route("/slotbooking", methods=['GET', 'POST'])
@login_required
@patient_required
def slotbooking():
    hospitals = HospitalData.query.all()

    # Get recent bookings for current user
    recent_bookings = Booking.query.filter_by(srfid=current_user.srfid).order_by(Booking.id.desc()).limit(5).all()

    if request.method == "POST":
        payment = request.form.get('payment')
        if not payment:
            flash("Please select a payment method", "danger")
            return render_template("booking.html", query=hospitals, recent_bookings=recent_bookings)
        
        data = {
            "srfid": current_user.srfid,
            "hcode": request.form.get('hcode'),
            "bedtype": request.form.get('bedtype'),
            "pname": request.form.get('pname'),
            "pphone": request.form.get('pphone'),
            "paddress": request.form.get('paddress'),
            "spo2": int(request.form.get('spo2', 0)),
            "payment_method": payment
        }

        hospital = HospitalData.query.filter_by(hcode=data["hcode"]).first()
        if not hospital:
            flash("Invalid hospital code", "danger")
            return render_template("booking.html", query=hospitals, recent_bookings=recent_bookings)

        available = (
            (data["bedtype"] == "NormalBed" and hospital.normalbed > 0) or
            (data["bedtype"] == "HICUBed" and hospital.hicubed > 0) or
            (data["bedtype"] == "ICUBed" and hospital.icubed > 0) or
            (data["bedtype"] == "VENTILATORBed" and hospital.vbed > 0)
        )

        if not available:
            flash("No beds available for selected type", "danger")
            return render_template("booking.html", query=hospitals, recent_bookings=recent_bookings)

        session["pending_booking"] = data
        return redirect(url_for("payment"))

    return render_template("booking.html", query=hospitals, recent_bookings=recent_bookings)

# -------------------- Payment Confirmation --------------------
@THB.route("/payment", methods=['GET'])
@login_required
@patient_required
def payment():
    data = session.get("pending_booking")
    if not data:
        flash("No booking found. Please fill the booking form.", "warning")
        return redirect(url_for("slotbooking"))

    return render_template(
        "payment.html",
        srfid=data["srfid"],
        pname=data["pname"],
        hcode=data["hcode"],
        bedtype=data["bedtype"],
        payment=data["payment_method"]
    )
@THB.route("/process_payment", methods=['POST'])
@login_required
@patient_required
def process_payment():
    srfid = request.form.get('srfid')
    pname = request.form.get('pname')
    hcode = request.form.get('hcode')
    bedtype = request.form.get('bedtype')
    payment = request.form.get('payment')

    # Save booking directly
    new_booking = Booking(
        srfid=srfid,
        pname=pname,
        hcode=hcode,
        bedtype=bedtype,
        payment_method=payment
    )
    db.session.add(new_booking)
    db.session.commit()
    flash("Booking successful!", "success")
    return redirect(url_for("payment_success"))


# -------------------- Process Payment --------------------
@THB.route("/payment_success")
@login_required
@patient_required
def payment_success():
    data = session.pop("pending_booking", None)
    if not data:
        flash("No booking found.", "warning")
        return redirect(url_for("slotbooking"))

    # Deduct booked bed from hospital database
    hospital = HospitalData.query.filter_by(hcode=data["hcode"]).first()
    if hospital:
        if data["bedtype"] == "NormalBed" and hospital.normalbed > 0:
            hospital.normalbed -= 1
        elif data["bedtype"] == "HICUBed" and hospital.hicubed > 0:
            hospital.hicubed -= 1
        elif data["bedtype"] == "ICUBed" and hospital.icubed > 0:
            hospital.icubed -= 1
        elif data["bedtype"] == "VENTILATORBed" and hospital.vbed > 0:
            hospital.vbed -= 1

        db.session.commit()  # Save bed deduction

    # ✅ Save booking to Booking table
    new_booking = Booking(
        srfid=data["srfid"],
        pname=data["pname"],
        hcode=data["hcode"],
        bedtype=data["bedtype"],
        payment_method=data["payment_method"],
        spo2=data["spo2"],
        pphone=data["pphone"],
        paddress=data["paddress"]
    )
    db.session.add(new_booking)
    db.session.commit()

    flash("Booking successful!", "success")
    return render_template(
        "success.html",
        pname=data["pname"],
        bedtype=data["bedtype"],
        payment=data["payment_method"]
    )

# Route to show all bookings for the current user
@THB.route("/booking_history")
@login_required
@patient_required
def booking_history():
    bookings = Booking.query.filter_by(srfid=current_user.srfid).order_by(Booking.id.desc()).all()
    return render_template("booking_history.html", bookings=bookings)


# Route to show details of a single booking
@THB.route("/pdetails/<int:booking_id>")
@login_required
@patient_required
def pdetails(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    return render_template("pdetails.html", data=booking)

# -------------------- View Seats --------------------
@THB.route('/view_seats')
def view_seats():
    hospitals = HospitalData.query.all()
    return render_template("view_seats.html", hospitals=hospitals)

# -------------------- Run App --------------------
with THB.app_context():
    db.create_all()

if __name__ == "__main__":
    THB.run(debug=True)
